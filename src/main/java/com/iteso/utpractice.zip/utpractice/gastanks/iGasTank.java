package com.iteso.utpractice.gastanks;

/**
 * Created by Carlos on 08/09/2015.
 */
public interface iGasTank {
    public float getGasLevel();
    public int getTankCapacity();
    public void addGass(float liters);
}
